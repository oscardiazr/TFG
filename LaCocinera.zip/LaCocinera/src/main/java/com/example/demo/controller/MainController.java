/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.example.demo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

/**
 *
 * @author oscar
 */
@Controller
public class MainController {

    @GetMapping("/")
    public String index() {
        return "index"; // devuelve el nombre de la plantilla HTML a renderizar (sin la extensión .html)
    }

    @GetMapping("/recetas")
    public String recetas() {
        return "recetas"; // nombre de la plantilla HTML para la página de recetas
    }

    @GetMapping("/favoritas")
    public String recetasFavoritas() {
        return "favoritas"; // nombre de la plantilla HTML para la página de recetas favoritas
    }

    @GetMapping("/curiosidades")
    public String curiosidades() {
        return "curiosidades"; // nombre de la plantilla HTML para la página de curiosidades culinarias
    }

    @GetMapping("/misrecetas")
    public String misRecetas() {
        return "misrecetas"; // nombre de la plantilla HTML para la página de mis recetas
    }   
}
