/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.example.demo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

/**
 *
 * @author oscar
 */
@Controller
public class RecetasController {

    @GetMapping("/mediterranea")
    public String mediterranea() {
        return "mediterranea";
    }

    @GetMapping("/francesa")
    public String francesa() {
        return "francesa";
    }

    @GetMapping("/italiana")
    public String italiana() {
        return "italiana";
    }

    @GetMapping("/china")
    public String china() {
        return "china";
    }

    @GetMapping("/japonesa")
    public String japonesa() {
        return "japonesa";
    }

    @GetMapping("/mexicana")
    public String mexicana() {
        return "mexicana";
    }

    @GetMapping("/india")
    public String india() {
        return "india";
    }

    @GetMapping("/tailandesa")
    public String tailandesa() {
        return "tailandesa";
    }

    @GetMapping("/brasilena")
    public String brasilena() {
        return "brasilena";
    }

    @GetMapping("/marroqui")
    public String marroqui() {
        return "marroqui";
    }
}
